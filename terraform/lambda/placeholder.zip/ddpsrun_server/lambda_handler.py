# Placeholder. CI publishes the real package.
def handler(event, context):
    return {"statusCode": 503, "body": "not deployed yet"}
